// Portage natif ESP-IDF du sketch Arduino SD_Card.ino
// Equivalent : FS.h/SD.h/SPI.h (Arduino) -> esp_vfs_fat.h/sdmmc_cmd.h/driver/sdspi_host.h (ESP-IDF)
//
// Cablage (identique au sketch Arduino, voir schema micro-SD) :
//   GPIO0 -> CMD_SD  (MOSI)
//   GPIO1 -> DAT3/CD_SD (CS)
//   GPIO2 -> DAT0_SD (MISO)
//   GPIO3 -> CLK_SD  (SCK)

#include <stdio.h>
#include <string.h>
#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"
#include "esp_log.h"

static const char *TAG = "sd_card_test";

#define PIN_NUM_MOSI 0  // CMD_SD
#define PIN_NUM_CS   1  // DAT3/CD_SD
#define PIN_NUM_MISO 2  // DAT0_SD
#define PIN_NUM_CLK  3  // CLK_SD

#define MOUNT_POINT "/sdcard"

void app_main(void)
{
    esp_err_t ret;

    ESP_LOGI(TAG, "Tentative de montage de la carte SD...");

    esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = false,
        .max_files = 5,
        .allocation_unit_size = 16 * 1024,
    };

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.max_freq_khz = 4000; // 4 MHz, comme dans le sketch Arduino d'origine

    spi_bus_config_t bus_cfg = {
        .mosi_io_num = PIN_NUM_MOSI,
        .miso_io_num = PIN_NUM_MISO,
        .sclk_io_num = PIN_NUM_CLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 4000,
    };

    ret = spi_bus_initialize(host.slot, &bus_cfg, SPI_DMA_CH_AUTO);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Echec init bus SPI (%s)", esp_err_to_name(ret));
        return;
    }

    sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_config.gpio_cs = PIN_NUM_CS;
    slot_config.host_id = host.slot;

    sdmmc_card_t *card;
    ret = esp_vfs_fat_sdspi_mount(MOUNT_POINT, &host, &slot_config, &mount_config, &card);
    if (ret != ESP_OK) {
        if (ret == ESP_FAIL) {
            ESP_LOGE(TAG, "Echec : Carte absente, mal formatee (exFAT ?), ou erreur SPI.");
        } else {
            ESP_LOGE(TAG, "Echec init carte (%s). Verifiez le cablage / les pull-ups R27-R29.", esp_err_to_name(ret));
        }
        return;
    }

    ESP_LOGI(TAG, "Carte SD detectee et montee avec succes en FAT32 !");
    sdmmc_card_print_info(stdout, card);

    FILE *f = fopen(MOUNT_POINT "/test_vtx.txt", "w");
    if (f == NULL) {
        ESP_LOGE(TAG, "Impossible d'ouvrir le fichier en ecriture");
        return;
    }
    fprintf(f, "Ecriture OK avec bus stabilise.\n");
    fclose(f);
    ESP_LOGI(TAG, "Fichier de test ecrit.");

    // Laisse la carte montee (contrairement au sketch Arduino qui ne fait rien dans loop())
}
