// Portage natif ESP-IDF du sketch Arduino Wifi_Validation_5GHz.ino
// Equivalent : WiFi.h/WebServer.h (Arduino) -> esp_wifi.h/esp_http_server.h (ESP-IDF)
//
// Difference cle : esp_wifi_set_band_mode(WIFI_BAND_MODE_5G_ONLY) force la bande 5GHz.
// Ce reglage n'est pas expose par l'API Arduino WiFi.softAP() sur l'ESP32-C5 au moment
// de l'ecriture -> c'est la raison technique principale de passer en ESP-IDF natif ici.

#include <string.h>
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_http_server.h"
#include "nvs_flash.h"

static const char *TAG = "wifi_5ghz_test";

#define WIFI_SSID "VTX"
#define WIFI_PASS "password123"     // >= 8 caracteres
#define WIFI_CHANNEL 36             // Canal 5GHz, bande UNII-1 (36/40/44/48)

static esp_err_t root_get_handler(httpd_req_t *req)
{
    const char *resp = "<h1>Bonjour Test WIFI</h1>";
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void start_webserver(void)
{
    httpd_handle_t server = NULL;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();

    if (httpd_start(&server, &config) == ESP_OK) {
        httpd_uri_t root_uri = {
            .uri = "/",
            .method = HTTP_GET,
            .handler = root_get_handler,
        };
        httpd_register_uri_handler(server, &root_uri);
        ESP_LOGI(TAG, "Serveur HTTP demarre.");
    }
}

static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                                int32_t event_id, void *event_data)
{
    if (event_id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t *event = (wifi_event_ap_staconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " connectee, AID=%d", MAC2STR(event->mac), event->aid);
    } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t *event = (wifi_event_ap_stadisconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " deconnectee, AID=%d", MAC2STR(event->mac), event->aid);
    }
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                          &wifi_event_handler, NULL, NULL));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = WIFI_SSID,
            .ssid_len = strlen(WIFI_SSID),
            .channel = WIFI_CHANNEL,
            .password = WIFI_PASS,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    // Force le fonctionnement en 5GHz uniquement (WiFi 6 dual-band de l'ESP32-C5)
    ESP_ERROR_CHECK(esp_wifi_set_band_mode(WIFI_BAND_MODE_5G_ONLY));

    ESP_LOGI(TAG, "Reseau VTX cree avec succes en 5GHz ! SSID=%s canal=%d", WIFI_SSID, WIFI_CHANNEL);

    esp_netif_ip_info_t ip_info;
    esp_netif_get_ip_info(ap_netif, &ip_info);
    ESP_LOGI(TAG, "Adresse IP de la page web : " IPSTR, IP2STR(&ip_info.ip));

    start_webserver();
}
