// ETAPE 2 : a lancer seulement apres validation reussie avec 03_camera_validate.
//
// Capture JPEG brut via PARLIO (OV5640, PCB custom) + point d'acces WiFi 5GHz
// (bande 5GHz only, canal 5GHz, adapte au recepteur "lollipop" 5.8GHz) + serveur
// HTTP proposant :
//   GET /stream          -> flux MJPEG (multipart/x-mixed-replace), latence minimale
//   GET /capture          -> une seule image JPEG
//   GET /quality?q=0..63  -> change la qualite JPEG a la volee (0 = meilleure qualite)
//   GET /settings         -> page HTML de reglages avances (luminosite/contraste/saturation/effet)
//   GET /settings?brightness=&contrast=&saturation=&effect= -> applique directement (API)
//   GET /status            -> {"fps": ...} pour l'affichage en surimpression cote navigateur
//
// ATTENTION - point a verifier vous-meme avant de compiler :
// Les fonctions esp_cam_sensor_handle->set_quality/set_brightness/set_contrast/
// set_saturation/set_special_effect(...) sont deduites par analogie avec l'API
// classique "sensor_t" d'espressif/esp32-camera (set_vflip/set_hmirror existent
// et sont confirmes dans la doc de esp_cam_io_parl ; les autres suivent la meme
// convention mais ne sont pas documentees explicitement au moment ou j'ecris ceci
// - le composant est en beta active). Si la compilation echoue sur l'une de ces
// lignes, ouvrez managed_components/haqqscripter__esp_cam_io_parl/.../esp_cam_sensor_io_parl.h
// et utilisez le nom exact du champ/de la fonction qui y est defini.

#include <string.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_event.h"
#include "esp_heap_caps.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "nvs_flash.h"

#include "esp_cam_io_parl.h"

static const char *TAG = "camera_stream_5ghz";

// ---- Cablage camera (identique a 03_camera_validate, voir schema FPC OV5640) ----
#define CAM_PWDN_PIN  -1
#define CAM_RESET_PIN -1
#define CAM_XCLK_PIN  26
#define CAM_SDA_PIN   25
#define CAM_SCL_PIN   24
#define CAM_D0_PIN 7
#define CAM_D1_PIN 9
#define CAM_D2_PIN 10
#define CAM_D3_PIN 8
#define CAM_D4_PIN 6
#define CAM_D5_PIN 27
#define CAM_D6_PIN 4
#define CAM_D7_PIN 5
#define CAM_PCLK_PIN 23
#define CAM_VSYNC_PIN -1
#define CAM_HREF_PIN  -1
#define CAM_HSYNC_PIN -1

#define FRAME_BUFFER_CAPS (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)

// ---- WiFi 5GHz (bande obligatoire pour eviter les interferences avec la radiocommande) ----
#define WIFI_SSID "VTX"
#define WIFI_PASS "password123"
#define WIFI_CHANNEL 36            // canal 5GHz - a ajuster selon votre lollipop 5.8GHz / regulateur RX
#define MAX_STA_CONN 1

#define PART_BOUNDARY "123456789000000000000987654321"
static const char *_STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char *_STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char *_STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

static esp_cam_io_parl_handle_t esp_cam_dvp_handle;
static esp_cam_sensor_io_parl_handle_t esp_cam_sensor_handle;

typedef struct {
    size_t size, index, count;
    int sum;
    int *values;
} ra_filter_t;

static ra_filter_t ra_filter;
static volatile uint32_t g_avg_frame_ms = 1;

static ra_filter_t *ra_filter_init(ra_filter_t *filter, size_t sample_size)
{
    memset(filter, 0, sizeof(ra_filter_t));
    filter->values = (int *)calloc(sample_size, sizeof(int));
    if (!filter->values) return NULL;
    filter->size = sample_size;
    return filter;
}

static int ra_filter_run(ra_filter_t *filter, int value)
{
    if (!filter->values) return value;
    filter->sum -= filter->values[filter->index];
    filter->values[filter->index] = value;
    filter->sum += value;
    filter->index = (filter->index + 1) % filter->size;
    if (filter->count < filter->size) filter->count++;
    return filter->sum / filter->count;
}

// ---------------------------------------------------------------------------
// WiFi AP en 5GHz
// ---------------------------------------------------------------------------
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                                int32_t event_id, void *event_data)
{
    if (event_id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t *event = (wifi_event_ap_staconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " connectee, AID=%d", MAC2STR(event->mac), event->aid);
    } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t *event = (wifi_event_ap_stadisconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " deconnectee, AID=%d, raison=%d",
                 MAC2STR(event->mac), event->aid, event->reason);
    }
}

static void wifi_init_softap_5ghz(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                          &wifi_event_handler, NULL, NULL));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = WIFI_SSID,
            .ssid_len = strlen(WIFI_SSID),
            .channel = WIFI_CHANNEL,
            .password = WIFI_PASS,
            .max_connection = MAX_STA_CONN,
            .authmode = WIFI_AUTH_WPA2_PSK,
        },
    };
    if (strlen(WIFI_PASS) == 0) {
        wifi_config.ap.authmode = WIFI_AUTH_OPEN;
    }

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    // Force la bande 5GHz uniquement (specifique ESP32-C5, WiFi 6 dual-band)
    ESP_ERROR_CHECK(esp_wifi_set_band_mode(WIFI_BAND_MODE_5G_ONLY));

    ESP_LOGI(TAG, "AP 5GHz demarre. SSID=%s canal=%d", WIFI_SSID, WIFI_CHANNEL);

    esp_netif_ip_info_t ip_info;
    esp_netif_get_ip_info(ap_netif, &ip_info);
    ESP_LOGI(TAG, "IP: " IPSTR, IP2STR(&ip_info.ip));
}

// ---------------------------------------------------------------------------
// Handlers HTTP
// ---------------------------------------------------------------------------
static esp_err_t capture_handler(httpd_req_t *req)
{
    esp_cam_io_parl_trans_t frame;
    if (esp_cam_io_parl_receive(esp_cam_dvp_handle, &frame, 5000) != ESP_OK) {
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }
    httpd_resp_set_type(req, "image/jpeg");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    esp_err_t res = httpd_resp_send(req, (const char *)frame.buffer, frame.length);
    esp_cam_io_parl_free_buffer(&frame);
    return res;
}

static esp_err_t stream_handler(httpd_req_t *req)
{
    esp_err_t res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
    if (res != ESP_OK) return res;
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    char part_buf[64];
    while (true) {
        int64_t last_frame = esp_timer_get_time();
        esp_cam_io_parl_trans_t image;
        if (esp_cam_io_parl_receive(esp_cam_dvp_handle, &image, 5000) != ESP_OK) {
            ESP_LOGE(TAG, "Echec de capture pendant le stream");
            res = ESP_FAIL;
            break;
        }
        res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
        if (res == ESP_OK) {
            size_t hlen = snprintf(part_buf, sizeof(part_buf), _STREAM_PART, (unsigned)image.length);
            res = httpd_resp_send_chunk(req, part_buf, hlen);
        }
        if (res == ESP_OK) {
            res = httpd_resp_send_chunk(req, (const char *)image.buffer, image.length);
        }
        esp_cam_io_parl_free_buffer(&image);
        if (res != ESP_OK) break;

        int64_t frame_time_ms = (esp_timer_get_time() - last_frame) / 1000;
        if (frame_time_ms <= 0) frame_time_ms = 1;
        // Mise a jour d'une simple variable en memoire (aucune I/O, cout negligeable)
        // au lieu d'un ESP_LOGI par frame - evite de solliciter l'UART en continu.
        g_avg_frame_ms = (uint32_t)ra_filter_run(&ra_filter, (int)frame_time_ms);
    }
    return res;
}

// GET /quality?q=0..63  (0 = meilleure qualite / plus gros fichiers)
static esp_err_t quality_handler(httpd_req_t *req)
{
    char query[32];
    char val[8];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "q", val, sizeof(val)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Parametre attendu : /quality?q=0..63");
        return ESP_FAIL;
    }
    int q = atoi(val);
    if (q < 0 || q > 63) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "q doit etre entre 0 et 63");
        return ESP_FAIL;
    }
    // Voir l'avertissement en tete de fichier si cette ligne ne compile pas.
    esp_cam_sensor_handle->set_quality(esp_cam_sensor_handle, q);
    ESP_LOGI(TAG, "Qualite JPEG changee -> %d", q);
    httpd_resp_sendstr(req, "OK");
    return ESP_OK;
}

// GET /status -> etat JSON pour l'OSD cote navigateur (interroge une fois par
// seconde - aucun cout sur le flux video, ca passe par le port de controle (80),
// pas le port de stream (81), et ne fait que lire une variable en memoire.
static esp_err_t status_handler(httpd_req_t *req)
{
    char json[64];
    uint32_t avg = g_avg_frame_ms;
    snprintf(json, sizeof(json), "{\"fps\":%.1f}", avg > 0 ? 1000.0 / avg : 0.0);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_sendstr(req, json);
    return ESP_OK;
}

// GET /settings              -> page HTML avec reglages complets (curseurs + effet)
// GET /settings?brightness=&contrast=&saturation=&effect= -> applique directement (API)
static esp_err_t settings_handler(httpd_req_t *req)
{
    char query[128];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK || query[0] == '\0') {
        const char *page =
            "<html><body style='background:#111;color:#0f0;font-family:monospace;padding:16px'>"
            "<h3>Reglages camera</h3>"
            "<p>Qualite JPEG (0=meilleure) <input type='range' min='0' max='63' value='10' id='q' "
            "oninput='deb(\"/quality?q=\"+this.value)'></p>"
            "<p>Luminosite <input type='range' min='-2' max='2' value='0' id='b' "
            "oninput='deb(\"/settings?brightness=\"+this.value)'></p>"
            "<p>Contraste <input type='range' min='-2' max='2' value='0' id='c' "
            "oninput='deb(\"/settings?contrast=\"+this.value)'></p>"
            "<p>Saturation <input type='range' min='-2' max='2' value='0' id='s' "
            "oninput='deb(\"/settings?saturation=\"+this.value)'></p>"
            "<p>Effet special <select onchange='fetch(\"/settings?effect=\"+this.value)'>"
            "<option value='0'>Aucun</option><option value='1'>Negatif</option>"
            "<option value='2'>Niveaux de gris</option><option value='3'>Sepia</option>"
            "</select></p>"
            "<p><a href='/' style='color:#0f0'>&larr; Retour au flux</a></p>"
            "<script>"
            "var t;function deb(url){clearTimeout(t);t=setTimeout(function(){fetch(url);},150);}"
            "</script></body></html>";
        httpd_resp_set_type(req, "text/html");
        httpd_resp_send(req, page, HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }

    char val[8], applied[96] = "";
    if (httpd_query_key_value(query, "brightness", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_brightness(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "brightness ");
    }
    if (httpd_query_key_value(query, "contrast", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_contrast(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "contrast ");
    }
    if (httpd_query_key_value(query, "saturation", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_saturation(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "saturation ");
    }
    if (httpd_query_key_value(query, "effect", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_special_effect(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "effect ");
    }
    httpd_resp_sendstr(req, applied[0] ? applied : "Aucun parametre reconnu");
    return ESP_OK;
}

static esp_err_t root_get_handler(httpd_req_t *req)
{
    // 192.168.4.1 est l'adresse par defaut du point d'acces ESP-IDF (softAP) -
    // fixe tant qu'on ne la reconfigure pas explicitement avec esp_netif_set_ip_info().
    const char *resp =
        "<html><body style='margin:0;background:#000'>"
        "<div style='position:relative'>"
        "<img src='http://192.168.4.1:81/stream' style='width:100%;display:block'>"
        "<div id='osd' style='position:absolute;top:8px;left:8px;color:#0f0;"
        "font-family:monospace;font-size:14px;text-shadow:1px 1px 2px #000;"
        "background:rgba(0,0,0,0.4);padding:4px 8px;border-radius:4px'>--</div>"
        "</div>"
        "<div style='padding:8px;font-family:monospace;color:#0f0'>"
        "Qualite <input type='range' min='0' max='63' value='10' oninput='deb(\"/quality?q=\"+this.value)'> "
        "Lumi. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?brightness=\"+this.value)'> "
        "Contr. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?contrast=\"+this.value)'> "
        "Sat. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?saturation=\"+this.value)'> "
        "Effet <select onchange='fetch(\"/settings?effect=\"+this.value)'>"
        "<option value='0'>Aucun</option><option value='1'>Negatif</option>"
        "<option value='2'>N&amp;B</option><option value='3'>Sepia</option></select> "
        "<a href='/settings' style='color:#0f0'>[Reglages avances]</a>"
        "</div>"
        "<script>"
        "var t;function deb(url){clearTimeout(t);t=setTimeout(function(){fetch(url);},150);}"
        "setInterval(function(){"
        "fetch('/status').then(function(r){return r.json();}).then(function(s){"
        "document.getElementById('osd').innerText=s.fps.toFixed(1)+' fps';"
        "});"
        "},1000);"
        "</script>"
        "</body></html>";
    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static void start_camera_server(void)
{
    httpd_handle_t stream_server = NULL;
    httpd_handle_t ctrl_server = NULL;

    httpd_config_t stream_config = HTTPD_DEFAULT_CONFIG();
    stream_config.server_port = 81;
    stream_config.ctrl_port = 32769;

    httpd_uri_t stream_uri = { .uri = "/stream", .method = HTTP_GET, .handler = stream_handler };
    if (httpd_start(&stream_server, &stream_config) == ESP_OK) {
        httpd_register_uri_handler(stream_server, &stream_uri);
        ESP_LOGI(TAG, "Serveur de stream sur le port %d", stream_config.server_port);
    }

    httpd_config_t ctrl_config = HTTPD_DEFAULT_CONFIG();
    ctrl_config.server_port = 80;
    httpd_uri_t root_uri = { .uri = "/", .method = HTTP_GET, .handler = root_get_handler };
    httpd_uri_t status_uri = { .uri = "/status", .method = HTTP_GET, .handler = status_handler };
    httpd_uri_t capture_uri = { .uri = "/capture", .method = HTTP_GET, .handler = capture_handler };
    httpd_uri_t quality_uri = { .uri = "/quality", .method = HTTP_GET, .handler = quality_handler };
    httpd_uri_t settings_uri = { .uri = "/settings", .method = HTTP_GET, .handler = settings_handler };
    if (httpd_start(&ctrl_server, &ctrl_config) == ESP_OK) {
        httpd_register_uri_handler(ctrl_server, &root_uri);
        httpd_register_uri_handler(ctrl_server, &status_uri);
        httpd_register_uri_handler(ctrl_server, &capture_uri);
        httpd_register_uri_handler(ctrl_server, &quality_uri);
        httpd_register_uri_handler(ctrl_server, &settings_uri);
        ESP_LOGI(TAG, "Serveur de controle sur le port %d", ctrl_config.server_port);
    }
}

void app_main(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    static esp_cam_sensor_io_parl_config_t sensor_config = {
        .pwdn_io = CAM_PWDN_PIN,
        .reset_io = CAM_RESET_PIN,
        .xclk_io = CAM_XCLK_PIN,
        .xclk_hz = 24000000,
        .sda_io = CAM_SDA_PIN,
        .scl_io = CAM_SCL_PIN,
        .pixel_format = ESP_CAM_IO_PARL_PIXFORMAT_JPEG,
        .frame_size = ESP_CAM_IO_PARL_FRAMESIZE_QVGA,   // 640x480, ~30-40fps attendu (cf mesures du composant)
        .jpeg_quality = 10,
    };

    esp_err_t err = esp_cam_new_sensor_io_parl(&sensor_config, &esp_cam_sensor_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Init camera echouee (0x%x)", err);
        return;
    }
    ESP_LOGI(TAG, "Camera OV5640 detectee ! Qualite = %u", esp_cam_sensor_handle->status.quality);

    esp_cam_sensor_handle->set_vflip(esp_cam_sensor_handle, true);
    esp_cam_sensor_handle->set_hmirror(esp_cam_sensor_handle, false);

    static esp_cam_io_parl_config_t dvp_config = {
        .data_width = 8,
        .queue_frames = 2,
        .fill_mode = ESP_CAM_IO_PARL_QUEUE_LATEST,   // toujours la derniere frame -> latence minimale
        .frame_heap_caps = FRAME_BUFFER_CAPS,
        .pclk_io = CAM_PCLK_PIN,
        .pclk_sample_edge = ESP_CAM_IO_PARL_PCLK_POS,
        .de_io = CAM_HREF_PIN,
        .hsync_io = CAM_HSYNC_PIN,
        .vsync_io = CAM_VSYNC_PIN,
        .data_io = {
            CAM_D0_PIN, CAM_D1_PIN, CAM_D2_PIN, CAM_D3_PIN,
            CAM_D4_PIN, CAM_D5_PIN, CAM_D6_PIN, CAM_D7_PIN,
        },
        .flags = { .allow_pd = true },
    };

    ESP_ERROR_CHECK(esp_cam_new_io_parl(&dvp_config, &esp_cam_dvp_handle));
    ESP_ERROR_CHECK(esp_cam_io_parl_enable(esp_cam_dvp_handle, true));
    ESP_ERROR_CHECK(esp_cam_sensor_io_parl_connect(esp_cam_dvp_handle));

    ra_filter_init(&ra_filter, 20);

    wifi_init_softap_5ghz();
    start_camera_server();
}
