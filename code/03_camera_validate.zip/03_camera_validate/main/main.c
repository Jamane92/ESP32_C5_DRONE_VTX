// ETAPE 1 : validation du lien camera OV5640 <-> PARLIO sur PCB custom.
//
// Objectif de ce projet : NE PAS faire de WiFi, NE PAS faire de streaming.
// Juste verifier que :
//   1) le SCCB/I2C repond (le composant logue "Camera detected!")
//   2) le PARLIO recoit bien des trames JPEG (taille + FPS logues en serie)
// Une fois que cette base fonctionne de maniere stable, passez au projet
// 04_camera_stream_5ghz qui ajoute le WiFi et le serveur MJPEG.
//
// Bibliotheque utilisee : haqqscripter/esp_cam_io_parl (beta communautaire),
// seule solution connue capable de piloter une camera DVP via PARLIO sur
// ESP32-C5 aujourd'hui (voir idf_component.yml).
//
// Cablage (d'apres le schema fourni - connecteur FPC OV5640) :
//   XCLK  -> GPIO26 (genere par LEDC/PWM cote ESP32, leve en 2.8V via U5 SN74LVC1G34)
//   SDA   -> GPIO25 (SDA_FPC)
//   SCL   -> GPIO24 (SCL_FPC)
//   PCLK  -> GPIO23 (PCLK_FPC)
//   D0..D7-> GPIO7, GPIO9, GPIO10, GPIO8, GPIO6, GPIO27, GPIO4, GPIO5
//   PWDN  -> non connecte a l'ESP32 (tire au GND en dur sur le PCB)
//   RESETB-> non connecte a l'ESP32 (tire au VCC en dur sur le PCB -> reset uniquement logiciel via SCCB)
//   VSYNC / HREF -> non cables (le composant ne les utilise pas sur ESP32-C5,
//                   il fonctionne en "PCLK gate" + trames JPEG uniquement, cf README)

#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_err.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "esp_timer.h"

#include "esp_cam_io_parl.h"

static const char *TAG = "camera_validate";

#define CAM_PWDN_PIN  -1
#define CAM_RESET_PIN -1     // reset logiciel via SCCB (RESETB cable en dur au VCC sur le PCB)
#define CAM_XCLK_PIN  26     // XCLK_3.3V_FPC (genere cote ESP32, leve en 2.8V par U5)
#define CAM_SDA_PIN   25
#define CAM_SCL_PIN   24

#define CAM_D0_PIN 7
#define CAM_D1_PIN 9
#define CAM_D2_PIN 10
#define CAM_D3_PIN 8
#define CAM_D4_PIN 6
#define CAM_D5_PIN 27
#define CAM_D6_PIN 4
#define CAM_D7_PIN 5
#define CAM_PCLK_PIN 23

// Camera absente de VSYNC/HREF cote ESP32-C5 avec ce composant -> toujours -1
#define CAM_VSYNC_PIN -1
#define CAM_HREF_PIN  -1
#define CAM_HSYNC_PIN -1

// N8R8 = 8 Mo PSRAM -> on stocke les frames JPEG en PSRAM
#define FRAME_BUFFER_CAPS (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)

static esp_cam_io_parl_handle_t esp_cam_dvp_handle;
static esp_cam_sensor_io_parl_handle_t esp_cam_sensor_handle;

// Moyenne glissante du temps de trame, pour lisser l'affichage du FPS
typedef struct {
    size_t size, index, count;
    int sum;
    int *values;
} ra_filter_t;

static ra_filter_t *ra_filter_init(ra_filter_t *filter, size_t sample_size)
{
    memset(filter, 0, sizeof(ra_filter_t));
    filter->values = (int *)calloc(sample_size, sizeof(int));
    if (!filter->values) {
        return NULL;
    }
    filter->size = sample_size;
    return filter;
}

static int ra_filter_run(ra_filter_t *filter, int value)
{
    if (!filter->values) {
        return value;
    }
    filter->sum -= filter->values[filter->index];
    filter->values[filter->index] = value;
    filter->sum += value;
    filter->index = (filter->index + 1) % filter->size;
    if (filter->count < filter->size) {
        filter->count++;
    }
    return filter->sum / filter->count;
}

static ra_filter_t ra_filter;

static void camera_task(void *args)
{
    while (true) {
        int64_t last_frame = esp_timer_get_time();
        esp_cam_io_parl_trans_t image;
        if (esp_cam_io_parl_receive(esp_cam_dvp_handle, &image, 5000) != ESP_OK) {
            ESP_LOGE(TAG, "Echec de capture - verifiez SDA/SCL/PCLK/XCLK et l'alimentation OV5640");
            continue;
        }
        int64_t frame_time_ms = (esp_timer_get_time() - last_frame) / 1000;
        if (frame_time_ms <= 0) frame_time_ms = 1;
        uint32_t avg = ra_filter_run(&ra_filter, (int)frame_time_ms);
        ESP_LOGI(TAG, "JPEG: %uB  %ums (%.1ffps)  moyenne: %ums (%.1ffps)",
                 (unsigned)image.length, (unsigned)frame_time_ms, 1000.0 / frame_time_ms,
                 (unsigned)avg, 1000.0 / avg);
        esp_cam_io_parl_free_buffer(&image);
    }
}

void app_main(void)
{
    static esp_cam_sensor_io_parl_config_t sensor_config = {
        .pwdn_io = CAM_PWDN_PIN,
        .reset_io = CAM_RESET_PIN,
        .xclk_io = CAM_XCLK_PIN,
        .xclk_hz = 20000000,   // 20 MHz : valeur de depart sure, a monter vers 24MHz une fois valide
        .sda_io = CAM_SDA_PIN,
        .scl_io = CAM_SCL_PIN,
        .pixel_format = ESP_CAM_IO_PARL_PIXFORMAT_JPEG,
        .frame_size = ESP_CAM_IO_PARL_FRAMESIZE_QVGA,  // 320x240 : petite resolution pour valider vite
        .jpeg_quality = 12,                            // 0-63, plus bas = meilleure qualite
    };

    esp_err_t err = esp_cam_new_sensor_io_parl(&sensor_config, &esp_cam_sensor_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Init camera echouee (0x%x). Verifiez le SCCB (GPIO24/25) et l'alimentation.", err);
        return;
    }
    ESP_LOGI(TAG, "Camera OV5640 detectee ! Qualite courante = %u", esp_cam_sensor_handle->status.quality);

    esp_cam_sensor_handle->set_vflip(esp_cam_sensor_handle, true);
    esp_cam_sensor_handle->set_hmirror(esp_cam_sensor_handle, false);

    static esp_cam_io_parl_config_t dvp_config = {
        .data_width = 8,
        .queue_frames = 2,
        .fill_mode = ESP_CAM_IO_PARL_QUEUE_LATEST,
        .frame_heap_caps = FRAME_BUFFER_CAPS,
        .pclk_io = CAM_PCLK_PIN,
        .pclk_sample_edge = ESP_CAM_IO_PARL_PCLK_POS,
        .de_io = CAM_HREF_PIN,
        .hsync_io = CAM_HSYNC_PIN,
        .vsync_io = CAM_VSYNC_PIN,
        .data_io = {
            CAM_D0_PIN, CAM_D1_PIN, CAM_D2_PIN, CAM_D3_PIN,
            CAM_D4_PIN, CAM_D5_PIN, CAM_D6_PIN, CAM_D7_PIN,
        },
        .flags = { .allow_pd = true },
    };

    ESP_ERROR_CHECK(esp_cam_new_io_parl(&dvp_config, &esp_cam_dvp_handle));
    ESP_ERROR_CHECK(esp_cam_io_parl_enable(esp_cam_dvp_handle, true));
    ESP_ERROR_CHECK(esp_cam_sensor_io_parl_connect(esp_cam_dvp_handle));

    ra_filter_init(&ra_filter, 20);

    xTaskCreate(camera_task, "camera_task", 4096, NULL, 5, NULL);
}
