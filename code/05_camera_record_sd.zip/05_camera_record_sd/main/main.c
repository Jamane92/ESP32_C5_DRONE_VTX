// ETAPE 3 : a lancer seulement apres validation reussie avec 04_camera_stream_5ghz.
//
// Ajoute par rapport a 04 :
//   - Montage carte micro-SD en SPI (memes pins que 01_sd_card_test)
//   - Une tache de capture UNIQUE et continue (capture_task) qui est desormais la
//     seule a appeler esp_cam_io_parl_receive() ; elle alimente :
//       a) un buffer partage (mutex) utilise par /stream et /capture
//       b) le fichier d'enregistrement SD quand un enregistrement est actif
//     (Avant, chaque requete HTTP /stream appelait esp_cam_io_parl_receive()
//      elle-meme : ca ne pouvait pas cohabiter avec un enregistrement simultane.)
//   - GET /record/start -> demarre l'enregistrement dans /sdcard/recNNN.mjpeg
//   - GET /record/stop  -> arrete, logue le nombre de frames et la taille ecrite
//   - GET /settings?brightness=&contrast=&saturation=&effect= -> reglages fins
//
// ATTENTION - a verifier vous-meme :
//   - set_quality (deja signale dans 04) et maintenant aussi set_brightness/
//     set_contrast/set_saturation/set_special_effect sont deduits par analogie
//     avec l'API "sensor_t" classique d'espressif/esp32-camera. Si la compilation
//     echoue sur l'une de ces lignes, ouvrez le header du composant :
//     managed_components/haqqscripter__esp_cam_io_parl/.../esp_cam_sensor_io_parl.h
//     et corrigez le nom exact.
//
// Lecture du fichier .mjpeg produit, sur votre PC (FFmpeg) :
//   ffplay -f mjpeg -framerate 24 rec000.mjpeg
//   ffmpeg -f mjpeg -framerate 24 -i rec000.mjpeg -c:v copy rec000.mp4
// ETAPE 3 : a lancer seulement apres validation reussie avec 04_camera_stream_5ghz

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_err.h"
#include "esp_system.h"
#include "esp_event.h"
#include "esp_heap_caps.h"
#include "esp_http_server.h"
#include "esp_log.h"
#include "esp_mac.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "lwip/sockets.h"

#include "esp_vfs_fat.h"
#include "sdmmc_cmd.h"
#include "driver/sdspi_host.h"
#include "driver/spi_common.h"

#include "esp_cam_io_parl.h"

static const char *TAG = "camera_record_sd";

// ---- Cablage camera ----
#define CAM_PWDN_PIN  -1
#define CAM_RESET_PIN -1
#define CAM_XCLK_PIN  26
#define CAM_SDA_PIN   25
#define CAM_SCL_PIN   24
#define CAM_D0_PIN 7
#define CAM_D1_PIN 9
#define CAM_D2_PIN 10
#define CAM_D3_PIN 8
#define CAM_D4_PIN 6
#define CAM_D5_PIN 27
#define CAM_D6_PIN 4
#define CAM_D7_PIN 5
#define CAM_PCLK_PIN 23
#define CAM_VSYNC_PIN -1
#define CAM_HREF_PIN  -1
#define CAM_HSYNC_PIN -1

#define FRAME_BUFFER_CAPS (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)
#define MAX_JPEG_FRAME_BYTES (96 * 1024)

// ---- Cablage carte SD ----
#define SD_PIN_MOSI 0
#define SD_PIN_CS   1
#define SD_PIN_MISO 2
#define SD_PIN_CLK  3
#define SD_MOUNT_POINT "/sdcard"

// ---- WiFi 5GHz ----
#define WIFI_SSID "VTX"
#define WIFI_PASS "password123"
#define WIFI_CHANNEL 36
#define MAX_STA_CONN 1

#define PART_BOUNDARY "123456789000000000000987654321"
static const char *_STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;

static esp_cam_io_parl_handle_t esp_cam_dvp_handle;
static esp_cam_sensor_io_parl_handle_t esp_cam_sensor_handle;

// ---------------------------------------------------------------------------
// Buffer de frame partage
// ---------------------------------------------------------------------------
typedef struct {
    uint8_t *buf;
    size_t len;
    uint32_t version;
    SemaphoreHandle_t mutex;
} shared_frame_t;

static shared_frame_t shared_frame;

// ---------------------------------------------------------------------------
// Etat d'enregistrement SD & Statistiques FPS
// ---------------------------------------------------------------------------
static volatile bool recording = false;
static FILE *record_file = NULL;
static uint32_t record_frame_count = 0;
static size_t record_bytes_written = 0;
static int64_t record_start_us = 0;
static int64_t last_duration_ms = 0; // Sauvegarde de la duree pour l'affichage OSD
static SemaphoreHandle_t record_mutex;

// Variables pour le calcul des FPS en temps reel
static volatile uint32_t current_capture_fps = 0;
static volatile uint32_t current_stream_fps = 0;
static uint32_t capture_frame_counter = 0;
static uint32_t stream_frame_counter = 0;
static int64_t last_fps_calc_time = 0;

// ---------------------------------------------------------------------------
// WiFi AP 5GHz
// ---------------------------------------------------------------------------
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                                int32_t event_id, void *event_data)
{
    if (event_id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t *event = (wifi_event_ap_staconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " connectee, AID=%d", MAC2STR(event->mac), event->aid);
    } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t *event = (wifi_event_ap_stadisconnected_t *) event_data;
        ESP_LOGI(TAG, "Station " MACSTR " deconnectee, AID=%d", MAC2STR(event->mac), event->aid);
    }
}

static void wifi_init_softap_5ghz(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                          &wifi_event_handler, NULL, NULL));

    wifi_config_t wifi_config = {
        .ap = {
            .ssid = WIFI_SSID,
            .ssid_len = strlen(WIFI_SSID),
            .channel = WIFI_CHANNEL,
            .password = WIFI_PASS,
            .max_connection = MAX_STA_CONN,
            .authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_ERROR_CHECK(esp_wifi_set_band_mode(WIFI_BAND_MODE_5G_ONLY));

    ESP_LOGI(TAG, "AP 5GHz demarre. SSID=%s canal=%d", WIFI_SSID, WIFI_CHANNEL);
    esp_netif_ip_info_t ip_info;
    esp_netif_get_ip_info(ap_netif, &ip_info);
    ESP_LOGI(TAG, "IP: " IPSTR, IP2STR(&ip_info.ip));
}

// ---------------------------------------------------------------------------
// Montage carte SD
// ---------------------------------------------------------------------------
static bool mount_sd_card(void)
{
    esp_vfs_fat_sdmmc_mount_config_t mount_config = {
        .format_if_mount_failed = false,
        .max_files = 4,
        .allocation_unit_size = 32 * 1024,
    };

    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.max_freq_khz = 20000; 

    spi_bus_config_t bus_cfg = {
        .mosi_io_num = SD_PIN_MOSI,
        .miso_io_num = SD_PIN_MISO,
        .sclk_io_num = SD_PIN_CLK,
        .quadwp_io_num = -1,
        .quadhd_io_num = -1,
        .max_transfer_sz = 4000,
    };

    if (spi_bus_initialize(host.slot, &bus_cfg, SPI_DMA_CH_AUTO) != ESP_OK) {
        ESP_LOGE(TAG, "Echec init bus SPI pour la SD");
        return false;
    }

    sdspi_device_config_t slot_config = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot_config.gpio_cs = SD_PIN_CS;
    slot_config.host_id = host.slot;

    sdmmc_card_t *card;
    esp_err_t ret = esp_vfs_fat_sdspi_mount(SD_MOUNT_POINT, &host, &slot_config, &mount_config, &card);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "Echec montage carte SD (%s)", esp_err_to_name(ret));
        return false;
    }
    ESP_LOGI(TAG, "Carte SD montee.");
    sdmmc_card_print_info(stdout, card);
    return true;
}

// ---------------------------------------------------------------------------
// Tache de capture continue
// ---------------------------------------------------------------------------
static void capture_task(void *arg)
{
    int consecutive_failures = 0;
    while (true) {
        int64_t now = esp_timer_get_time();
        if (now - last_fps_calc_time >= 1000000) {
            current_capture_fps = capture_frame_counter;
            current_stream_fps = stream_frame_counter;
            capture_frame_counter = 0;
            stream_frame_counter = 0;
            last_fps_calc_time = now;
        }

        esp_cam_io_parl_trans_t image;
        if (esp_cam_io_parl_receive(esp_cam_dvp_handle, &image, 2000) != ESP_OK) {
            ESP_LOGE(TAG, "Echec de capture (%d consecutifs)", ++consecutive_failures);
            if (consecutive_failures >= 5) {
                ESP_LOGE(TAG, "Camera bloquee de maniere persistante - redemarrage volontaire.");
                vTaskDelay(pdMS_TO_TICKS(100));
                esp_restart();
            }
            vTaskDelay(pdMS_TO_TICKS(50));
            continue;
        }
        consecutive_failures = 0;

        if (image.length <= MAX_JPEG_FRAME_BYTES) {
            xSemaphoreTake(shared_frame.mutex, portMAX_DELAY);
            memcpy(shared_frame.buf, image.buffer, image.length);
            shared_frame.len = image.length;
            shared_frame.version++;
            xSemaphoreGive(shared_frame.mutex);
            
            capture_frame_counter++; 
        } else {
            ESP_LOGW(TAG, "Frame ignoree pour /stream : %uB > MAX_JPEG_FRAME_BYTES", (unsigned)image.length);
        }

        if (recording) {
            xSemaphoreTake(record_mutex, portMAX_DELAY);
            if (recording && record_file != NULL) {
                size_t written = fwrite(image.buffer, 1, image.length, record_file);
                if (written != image.length) {
                    ESP_LOGE(TAG, "Ecriture SD incomplete (carte pleine ?) - arret de l'enregistrement");
                    fclose(record_file);
                    record_file = NULL;
                    recording = false;
                } else {
                    record_frame_count++;
                    record_bytes_written += written;
                }
            }
            xSemaphoreGive(record_mutex);
        }

        esp_cam_io_parl_free_buffer(&image);
    }
}

// ---------------------------------------------------------------------------
// Handlers HTTP
// ---------------------------------------------------------------------------
static esp_err_t status_handler(httpd_req_t *req)
{
    char json[256];
    xSemaphoreTake(record_mutex, portMAX_DELAY);
    
    // Si l'enregistrement est fini, on garde la derniere duree pour afficher la moyenne finale.
    int64_t elapsed_ms = recording ? (esp_timer_get_time() - record_start_us) / 1000 : last_duration_ms;
    
    snprintf(json, sizeof(json),
             "{\"recording\":%s,\"frames\":%u,\"bytes\":%u,\"elapsed_ms\":%lld,\"cap_fps\":%lu,\"str_fps\":%lu}",
             recording ? "true" : "false",
             (unsigned)record_frame_count, (unsigned)record_bytes_written, elapsed_ms,
             current_capture_fps, current_stream_fps);
    xSemaphoreGive(record_mutex);
    
    httpd_resp_set_type(req, "application/json");
    httpd_resp_sendstr(req, json);
    return ESP_OK;
}

static esp_err_t root_get_handler(httpd_req_t *req)
{
    const char *resp =
        "<html><body style='margin:0;background:#000'>"
        "<div style='position:relative'>"
        "<img src='http://192.168.4.1:81/stream' style='width:100%;display:block'>"
        "<div id='osd' style='position:absolute;top:8px;left:8px;color:#0f0;"
        "font-family:monospace;font-size:14px;text-shadow:1px 1px 2px #000;"
        "background:rgba(0,0,0,0.6);padding:6px 10px;border-radius:4px'>--</div>"
        "</div>"
        "<div style='padding:8px;font-family:monospace'>"
        "<button id='btnStart' onclick='recStart()' "
        "style='font-size:16px;padding:8px 16px;background:#040;color:#0f0;border:1px solid #0f0'>REC START</button> "
        "<button id='btnStop' onclick='recStop()' "
        "style='font-size:16px;padding:8px 16px;background:#400;color:#f66;border:1px solid #f66'>REC STOP</button>"
        "<br><br>"
        "<span style='color:#0f0'>Qualite <input type='range' min='0' max='63' value='10' "
        "oninput='deb(\"/quality?q=\"+this.value)'> "
        "Lumi. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?brightness=\"+this.value)'> "
        "Contr. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?contrast=\"+this.value)'> "
        "Sat. <input type='range' min='-2' max='2' value='0' oninput='deb(\"/settings?saturation=\"+this.value)'> "
        "Effet <select onchange='fetch(\"/settings?effect=\"+this.value)'>"
        "<option value='0'>Aucun</option><option value='1'>Negatif</option>"
        "<option value='2'>N&amp;B</option><option value='3'>Sepia</option></select> "
        "<a href='/settings' style='color:#0f0'>[Reglages avances]</a></span>"
        "</div>"
        "<script>"
        "var t;function deb(url){clearTimeout(t);t=setTimeout(function(){fetch(url);},150);}"
        "function recStart(){fetch('/record/start');}"
        "function recStop(){fetch('/record/stop');}"
        "function fmtTime(ms){var s=Math.floor(ms/1000);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}"
        "setInterval(function(){"
        "var start = Date.now();"
        "fetch('/status').then(function(r){return r.json();}).then(function(s){"
        "var ping = Date.now() - start;"
        "var osd=document.getElementById('osd');"
        "var statusText = '';"
        "if(s.recording){"
        "statusText='\u25cf REC '+fmtTime(s.elapsed_ms)+' - '+s.frames+'f - '+(s.bytes/1024).toFixed(0)+'Ko';"
        "osd.style.color='#f66';"
        "}else if(s.frames>0 && s.elapsed_ms>0){"
        "var avg_fps=(s.frames*1000/s.elapsed_ms).toFixed(1);"
        "statusText='Dernier enreg. : '+s.frames+'f, '+(s.bytes/1024/1024).toFixed(1)+'Mo ('+avg_fps+' fps moy.)';"
        "osd.style.color='#0f0';"
        "}else{"
        "statusText='Pret';"
        "osd.style.color='#0f0';"
        "}"
        "osd.innerHTML = statusText + '<br><span style=\"color:#ff0;font-size:12px;\">Latence: ' + ping + 'ms | Cam: ' + s.cap_fps + ' fps | Wi-Fi: ' + s.str_fps + ' fps</span>';"
        "});"
        "},1000);"
        "</script>"
        "</body></html>";
    httpd_resp_set_type(req, "text/html");
    httpd_resp_send(req, resp, HTTPD_RESP_USE_STRLEN);
    return ESP_OK;
}

static esp_err_t capture_handler(httpd_req_t *req)
{
    xSemaphoreTake(shared_frame.mutex, portMAX_DELAY);
    esp_err_t res = httpd_resp_set_type(req, "image/jpeg");
    if (res == ESP_OK) {
        httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
        res = httpd_resp_send(req, (const char *)shared_frame.buf, shared_frame.len);
    }
    xSemaphoreGive(shared_frame.mutex);
    return res;
}

static esp_err_t stream_handler(httpd_req_t *req)
{
    esp_err_t res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
    if (res != ESP_OK) return res;
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");

    int sockfd = httpd_req_to_sockfd(req);
    int flag = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, &flag, sizeof(flag));

    uint8_t *local_buf = heap_caps_malloc(MAX_JPEG_FRAME_BYTES, MALLOC_CAP_SPIRAM);
    char part_buf[96];
    uint32_t last_version = 0;

    while (true) {
        while (shared_frame.version == last_version) {
            vTaskDelay(pdMS_TO_TICKS(20)); 
        }
        
        size_t local_len;
        xSemaphoreTake(shared_frame.mutex, portMAX_DELAY);
        local_len = shared_frame.len;
        memcpy(local_buf, shared_frame.buf, local_len);
        last_version = shared_frame.version;
        xSemaphoreGive(shared_frame.mutex);

        int hlen = snprintf(part_buf, sizeof(part_buf),
                             "\r\n--" PART_BOUNDARY "\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",
                             (unsigned)local_len);
        res = httpd_resp_send_chunk(req, part_buf, hlen);
        if (res == ESP_OK) {
            res = httpd_resp_send_chunk(req, (const char *)local_buf, local_len);
            if (res == ESP_OK) stream_frame_counter++; 
        }
        if (res != ESP_OK) break;
    }

    heap_caps_free(local_buf);
    return res;
}

static esp_err_t quality_handler(httpd_req_t *req)
{
    char query[64], val[8];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK ||
        httpd_query_key_value(query, "q", val, sizeof(val)) != ESP_OK) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Parametre attendu : /quality?q=0..63");
        return ESP_FAIL;
    }
    int q = atoi(val);
    if (q < 0 || q > 63) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "q doit etre entre 0 et 63");
        return ESP_FAIL;
    }
    esp_cam_sensor_handle->set_quality(esp_cam_sensor_handle, q);
    ESP_LOGI(TAG, "Qualite -> %d", q);
    httpd_resp_sendstr(req, "OK");
    return ESP_OK;
}

static esp_err_t settings_handler(httpd_req_t *req)
{
    char query[128];
    if (httpd_req_get_url_query_str(req, query, sizeof(query)) != ESP_OK || query[0] == '\0') {
        const char *page =
            "<html><body style='background:#111;color:#0f0;font-family:monospace;padding:16px'>"
            "<h3>Reglages camera</h3>"
            "<p>Qualite JPEG (0=meilleure) <input type='range' min='0' max='63' value='10' "
            "oninput='deb(\"/quality?q=\"+this.value)'></p>"
            "<p>Luminosite <input type='range' min='-2' max='2' value='0' "
            "oninput='deb(\"/settings?brightness=\"+this.value)'></p>"
            "<p>Contraste <input type='range' min='-2' max='2' value='0' "
            "oninput='deb(\"/settings?contrast=\"+this.value)'></p>"
            "<p>Saturation <input type='range' min='-2' max='2' value='0' "
            "oninput='deb(\"/settings?saturation=\"+this.value)'></p>"
            "<p>Effet special <select onchange='fetch(\"/settings?effect=\"+this.value)'>"
            "<option value='0'>Aucun</option><option value='1'>Negatif</option>"
            "<option value='2'>Niveaux de gris</option><option value='3'>Sepia</option>"
            "</select></p>"
            "<p><a href='/' style='color:#0f0'>&larr; Retour au flux</a></p>"
            "<script>"
            "var t;function deb(url){clearTimeout(t);t=setTimeout(function(){fetch(url);},150);}"
            "</script></body></html>";
        httpd_resp_set_type(req, "text/html");
        httpd_resp_send(req, page, HTTPD_RESP_USE_STRLEN);
        return ESP_OK;
    }
    char val[8];
    char applied[128] = "";
    if (httpd_query_key_value(query, "brightness", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_brightness(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "brightness ");
    }
    if (httpd_query_key_value(query, "contrast", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_contrast(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "contrast ");
    }
    if (httpd_query_key_value(query, "saturation", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_saturation(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "saturation ");
    }
    if (httpd_query_key_value(query, "effect", val, sizeof(val)) == ESP_OK) {
        esp_cam_sensor_handle->set_special_effect(esp_cam_sensor_handle, atoi(val));
        strcat(applied, "effect ");
    }
    ESP_LOGI(TAG, "Reglages appliques : %s", applied[0] ? applied : "(aucun)");
    httpd_resp_sendstr(req, applied[0] ? applied : "Aucun parametre reconnu");
    return ESP_OK;
}

static esp_err_t record_start_handler(httpd_req_t *req)
{
    xSemaphoreTake(record_mutex, portMAX_DELAY);
    if (recording) {
        xSemaphoreGive(record_mutex);
        httpd_resp_sendstr(req, "Deja en cours d'enregistrement");
        return ESP_OK;
    }

    char path[64];
    struct stat st;
    int idx = 0;
    do {
        snprintf(path, sizeof(path), SD_MOUNT_POINT "/rec%03d.mjpeg", idx++);
    } while (stat(path, &st) == 0 && idx < 1000);

    record_file = fopen(path, "wb");
    if (!record_file) {
        xSemaphoreGive(record_mutex);
        ESP_LOGE(TAG, "Impossible de creer %s", path);
        httpd_resp_send_500(req);
        return ESP_FAIL;
    }
    record_frame_count = 0;
    record_bytes_written = 0;
    last_duration_ms = 0;
    record_start_us = esp_timer_get_time();
    recording = true;
    xSemaphoreGive(record_mutex);

    ESP_LOGI(TAG, "Enregistrement demarre -> %s", path);
    char resp[96];
    snprintf(resp, sizeof(resp), "REC START %s", path);
    httpd_resp_sendstr(req, resp);
    return ESP_OK;
}

static esp_err_t record_stop_handler(httpd_req_t *req)
{
    xSemaphoreTake(record_mutex, portMAX_DELAY);
    if (!recording) {
        xSemaphoreGive(record_mutex);
        httpd_resp_sendstr(req, "Pas d'enregistrement en cours");
        return ESP_OK;
    }
    recording = false;
    if (record_file) {
        fclose(record_file);
        record_file = NULL;
    }
    int64_t duration_ms = (esp_timer_get_time() - record_start_us) / 1000;
    last_duration_ms = duration_ms; 
    uint32_t frames = record_frame_count;
    size_t bytes = record_bytes_written;
    xSemaphoreGive(record_mutex);

    float avg_fps = duration_ms > 0 ? (frames * 1000.0f / duration_ms) : 0.0f;
    ESP_LOGI(TAG, "Enregistrement arrete : %u frames, %u octets, %lld ms, %.1f FPS moyen",
             (unsigned)frames, (unsigned)bytes, duration_ms, avg_fps);
             
    char resp[160];
    snprintf(resp, sizeof(resp), "REC STOP - %u frames, %u octets (%.1f Ko), %lldms (%.1f fps moyen)",
             (unsigned)frames, (unsigned)bytes, bytes / 1024.0, duration_ms, avg_fps);
    httpd_resp_sendstr(req, resp);
    return ESP_OK;
}

static void start_camera_server(void)
{
    httpd_handle_t stream_server = NULL;
    httpd_handle_t ctrl_server = NULL;

    httpd_config_t stream_config = HTTPD_DEFAULT_CONFIG();
    stream_config.server_port = 81;
    stream_config.ctrl_port = 32769;
    httpd_uri_t stream_uri = { .uri = "/stream", .method = HTTP_GET, .handler = stream_handler };
    if (httpd_start(&stream_server, &stream_config) == ESP_OK) {
        httpd_register_uri_handler(stream_server, &stream_uri);
        ESP_LOGI(TAG, "Serveur de stream sur le port %d", stream_config.server_port);
    }

    httpd_config_t ctrl_config = HTTPD_DEFAULT_CONFIG();
    ctrl_config.server_port = 80;

    httpd_uri_t root_uri = { .uri = "/", .method = HTTP_GET, .handler = root_get_handler };
    httpd_uri_t status_uri = { .uri = "/status", .method = HTTP_GET, .handler = status_handler };
    httpd_uri_t capture_uri = { .uri = "/capture", .method = HTTP_GET, .handler = capture_handler };
    httpd_uri_t quality_uri = { .uri = "/quality", .method = HTTP_GET, .handler = quality_handler };
    httpd_uri_t settings_uri = { .uri = "/settings", .method = HTTP_GET, .handler = settings_handler };
    httpd_uri_t rec_start_uri = { .uri = "/record/start", .method = HTTP_GET, .handler = record_start_handler };
    httpd_uri_t rec_stop_uri = { .uri = "/record/stop", .method = HTTP_GET, .handler = record_stop_handler };
    
    if (httpd_start(&ctrl_server, &ctrl_config) == ESP_OK) {
        httpd_register_uri_handler(ctrl_server, &root_uri);
        httpd_register_uri_handler(ctrl_server, &status_uri);
        httpd_register_uri_handler(ctrl_server, &capture_uri);
        httpd_register_uri_handler(ctrl_server, &quality_uri);
        httpd_register_uri_handler(ctrl_server, &settings_uri);
        httpd_register_uri_handler(ctrl_server, &rec_start_uri);
        httpd_register_uri_handler(ctrl_server, &rec_stop_uri);
        ESP_LOGI(TAG, "Serveur de controle sur le port %d", ctrl_config.server_port);
    }
}

void app_main(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    if (!mount_sd_card()) {
        ESP_LOGE(TAG, "Abandon : la SD est requise pour ce firmware.");
        return;
    }

    static esp_cam_sensor_io_parl_config_t sensor_config = {
        .pwdn_io = CAM_PWDN_PIN,
        .reset_io = CAM_RESET_PIN,
        .xclk_io = CAM_XCLK_PIN,
        .xclk_hz = 24000000,
        .sda_io = CAM_SDA_PIN,
        .scl_io = CAM_SCL_PIN,
        .pixel_format = ESP_CAM_IO_PARL_PIXFORMAT_JPEG,
        .frame_size = ESP_CAM_IO_PARL_FRAMESIZE_SVGA,
        .jpeg_quality = 10,
    };

    esp_err_t err = esp_cam_new_sensor_io_parl(&sensor_config, &esp_cam_sensor_handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Init camera echouee (0x%x)", err);
        return;
    }
    ESP_LOGI(TAG, "Camera OV5640 detectee !");
    esp_cam_sensor_handle->set_vflip(esp_cam_sensor_handle, true);
    esp_cam_sensor_handle->set_hmirror(esp_cam_sensor_handle, false);

    static esp_cam_io_parl_config_t dvp_config = {
        .data_width = 8,
        .queue_frames = 2,
        .fill_mode = ESP_CAM_IO_PARL_QUEUE_LATEST,
        .frame_heap_caps = FRAME_BUFFER_CAPS,
        .pclk_io = CAM_PCLK_PIN,
        .pclk_sample_edge = ESP_CAM_IO_PARL_PCLK_POS,
        .de_io = CAM_HREF_PIN,
        .hsync_io = CAM_HSYNC_PIN,
        .vsync_io = CAM_VSYNC_PIN,
        .data_io = {
            CAM_D0_PIN, CAM_D1_PIN, CAM_D2_PIN, CAM_D3_PIN,
            CAM_D4_PIN, CAM_D5_PIN, CAM_D6_PIN, CAM_D7_PIN,
        },
        .flags = { .allow_pd = true },
    };

    ESP_ERROR_CHECK(esp_cam_new_io_parl(&dvp_config, &esp_cam_dvp_handle));
    ESP_ERROR_CHECK(esp_cam_io_parl_enable(esp_cam_dvp_handle, true));
    ESP_ERROR_CHECK(esp_cam_sensor_io_parl_connect(esp_cam_dvp_handle));

    shared_frame.buf = heap_caps_malloc(MAX_JPEG_FRAME_BYTES, MALLOC_CAP_SPIRAM);
    shared_frame.mutex = xSemaphoreCreateMutex();
    record_mutex = xSemaphoreCreateMutex();

    wifi_init_softap_5ghz();
    start_camera_server();

    xTaskCreate(capture_task, "capture_task", 4096, NULL, 6, NULL);
}